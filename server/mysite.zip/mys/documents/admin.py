from django.contrib import admin

from .models import AquariumInfo
admin.site.register(AquariumInfo)
# Register your models here.
